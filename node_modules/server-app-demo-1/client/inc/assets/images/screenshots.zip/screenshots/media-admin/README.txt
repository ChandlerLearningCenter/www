
This is the Media Admin application that I built for BET.  The front-end was completely written in JavaScript using the ExtJS framework.  The back-end used a service-oriented architecture.

