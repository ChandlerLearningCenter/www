
Phojo.com is no longer up and running.  It was a photo sharing website that I designed and built with no additional technical help.  At its height, it had several thousand users from all over the world.  I ended up taking it down for financial and legal reasons.  

Notes:

The image cropping and annotation was done with ActionScript.  

The image manipulation was done server-side with Microsoft's GDI+.


